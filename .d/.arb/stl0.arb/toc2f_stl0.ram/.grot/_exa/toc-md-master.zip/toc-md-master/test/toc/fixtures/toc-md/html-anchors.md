<!-- TOC -->
- [h1](#redefined-anchor-for-h1)
- [h2](#h2)
- [h3](#h3)
- [h4](#h4)

<!-- TOC END -->

<a name="redefined-anchor-for-h1"></a>

# h1

```html
<a name = "should-not-redefine-anchor-for-h2">
```

# h2

<a href="href"></a>

# h3

<code>code</code>

# h4

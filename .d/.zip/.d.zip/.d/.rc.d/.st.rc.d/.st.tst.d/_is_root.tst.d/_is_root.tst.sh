#!/bin/bash

if _is_root ${HOME} >/dev/null; then
    echo "true"
fi

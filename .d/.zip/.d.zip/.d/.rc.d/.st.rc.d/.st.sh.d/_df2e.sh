#!/bin/bash

_df2e() {

    if [ "-h" == "$1" ]; then
        echo -e "
MAIN: ${FUNCNAME} :: ls \$1 only nfiles [, flt only \$2=.ext]
TAGS: @ls @nfile
\$1 
[, \$2]
"
        return 0
    fi

    if ! [[ -d "$1" ]]; then
        echo "in .d/.rc.d/.st.rc.d/.st.sh.d/_df2e.sh _d2e() : NOT_DIR : file://$1, hint : '$2' return 1" >&2
        return 1
    fi

    local item

    for item in $(ls "$1"); do
        if [ -z "$2" ]; then
            if [ -f "$1/$item" ] && [ "${item:0:1}" != "_" ]; then
                echo "$item"
            fi
        else
            local _df2e_ext
            _df2e_ext=$(_prs_f -e "$item")
            if [ -f "$1/$item" ] && [ "${item:0:1}" != "_" ] && [ "${_df2e_ext}" == "$2" ]; then
                echo "$item"
            fi

        fi
    done

}

#!/bin/bash

. ${HOME}/.st.rc.d/.st.stash.d/_cr_dir_tst.sh